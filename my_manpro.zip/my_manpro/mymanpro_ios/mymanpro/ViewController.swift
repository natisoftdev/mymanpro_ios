//
//  ViewController.swift
//  mymanpro
//
//  Created by Mac Studio Natisoft on 08/11/22.
//  Developer: Lorenzo Malferrari
//

import UIKit
import WebKit

class ViewController: UIViewController {
    
    let linkMyManPro: String = "https://uae.manpronet.com/mobile/my_manpro/account/index.php"
    
    let webView: WKWebView = {
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        
        let config = WKWebViewConfiguration()
        config.defaultWebpagePreferences = prefs
        
        let webview = WKWebView(frame: .zero, configuration: config)
        
        return webview
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(webView)
        
        guard let url = URL(string: linkMyManPro) else {
         return
        }
        
        webView.load(URLRequest(url: url))
        webView.customUserAgent = "iPad/Chrome/SomethingRandom"
        
        DispatchQueue.main.asyncAfter(deadline: .now()+21){
            self.webView.evaluateJavaScript("document.body.innerHTML") { result, error in
                guard let html = result as? String, error == nil else {
                    return
                }
                print(html)
            }
        }
        
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        webView.frame = view.bounds
    }
}
